const cacheName = 'demo-20231019';
const itemsToCache = [
  '/index.html'
];

self.addEventListener('install', event => {
  console.log('Service worker: install', event);
  event.waitUntil(
    (async () => {
      const cache = await caches.open(cacheName);
      console.log('Caching all');
      await cache.addAll(itemsToCache);
    })(),
  );
});

self.addEventListener('activate', event => {
  console.log('Service worker: activate', event);
});

self.addEventListener('fetch', event => {
  console.log('Service worker: fetch', event);
  // TODO: serve from cache, etc.
});